export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-pink-500">
      <h1 className="text-5xl font-bold text-white shadow-lg">
        Tailwind is Working! 🎉
      </h1>
    </div>
  )
}
